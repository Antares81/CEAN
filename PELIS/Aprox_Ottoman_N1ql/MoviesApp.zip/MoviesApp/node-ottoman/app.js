var Couchbase = require("couchbase");
var Ottoman = require("ottoman");
var BodyParser = require("body-parser");
var Cors = require("cors");
var Express = require("express");

var app = Express();

app.use(BodyParser.json());
app.use(Cors())

var bucket = (new Couchbase.Cluster("couchbase://localhost")).openBucket("movies");
Ottoman.store = new Ottoman.CbStoreAdapter(bucket, Couchbase);
module.exports.bucket = bucket;

var movieRouter = Express.Router();
app.use('/movies', movieRouter);


var MovieCtroller = require('./controllers/movies/movie.controller');
var controller = new MovieCtroller(movieRouter);


Ottoman.ensureIndices(function(error) {
    app.listen(3000, function() {
        console.log("Starting server on port 3000...");
    });
});