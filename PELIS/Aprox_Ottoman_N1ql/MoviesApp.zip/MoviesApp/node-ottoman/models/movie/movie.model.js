var Couchbase = require("couchbase");
var Ottoman = require("ottoman");
var bucket = require('../../app').bucket;

Ottoman.store = new Ottoman.CbStoreAdapter(bucket, Couchbase);

var MovieModel = Ottoman.model("Movie", {
    name: {type: "string"},
    genre: {type: "string"},
    formats: {
        digital: {type: "boolean"},
        bluray: {type: "boolean"},
        dvd: {type: "boolean"}
    }
});

module.exports = MovieModel;