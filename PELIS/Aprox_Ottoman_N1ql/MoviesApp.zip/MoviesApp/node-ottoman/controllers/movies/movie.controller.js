var Ottoman = require("ottoman");

const MovieModel = require('../../models/movie/movie.model');
      
class MovieController {
    
    constructor(router) {
        router.get('/', this.getMovies.bind(this));
        router.get('/:title', this.getMovieByTitle.bind(this));
        router.post('/', this.insertMovie.bind(this));
        //router.put('/:id', this.updateMovie.bind(this));
        //router.delete('/:id', this.deleteMovie.bind(this));
    }   
    
    getMovies(req, res) {
        console.log('*** getMovies');
        
        MovieModel.find({}, {consistency: Ottoman.Consistency.GLOBAL}, function(error, result) {
            if (error){
                return res.status(400).send({ "message": "Error.Sin registros a mostrar" });
            }    
            res.send(result);
        });
    }

    getMovieByTitle(req, res) {
        console.log('*** getMovieByTitle');
        const title = req.params.title;
        if(!req.params.title) {
            return res.status(400).send({ "message": "Missing `title` parameter" });
        }
        MovieModel.find({name: {$like: "%" + req.params.title + "%"}}, function(error, result) {
            if(error) {
                return res.status(400).send({ "message": error });
            }
            res.send(result);
        });
    }

    getMovie(req, res) {
        console.log('*** getMovie');
        
    }

    insertMovie(req, res) {
        console.log('*** insertMovie');
        if(!req.body.name) {
            return res.status(400).send({ "message": "Falta propiedad nombre" });
        } else if(!req.body.genre) {
            return res.status(400).send({ "message": "Falta propiedad genero" });
        }
        
    }

    updateMovie(req, res) {
        //TODO: opcional
        console.log('*** updateMovie');
        console.log('*** req.body');
        console.log(req.body);

    }

    deleteMovie(req, res) {
        //TODO: opcional
        console.log('*** deleteMovie');
}

}

module.exports = MovieController;